(function(){

const UI = {
  en: {
    heroTitle:"Learn Python the way you learnt to talk.",
    heroSub:"No one handed you a grammar book before your first word. You pointed, you copied, you tried, someone smiled or corrected you. That's exactly how EasyPy teaches Python — one small, real habit at a time.",
    heroCta:"Start Lesson 1 →",
    done:"done",
    motherLabel:"How you'd say it",
    pythonLabel:"How Python says it",
    codeTag:"Try this code",
    predictLabel:"Before you run it — what do you think this prints?",
    predictPh:"Type your guess here (optional)...",
    revealBtn:"Reveal the real output",
    actualOutput:"Actual output",
    quizHeading:"Check yourself",
    correct:"That's it — you've got it.",
    wrong:"Not quite. Look at the bridge card again and try once more.",
    prev:"← Previous",
    next:"Next lesson →",
    finishTitle:"You've finished every lesson 🎉",
    finishSub:"Seriously — that's real Python, learnt the way a language sticks: by using it, not by memorising rules. Go write something small and messy with it.",
    restart:"Revisit lessons",
    downloadCert:"Download your certificate",
    lessonWord:"Lesson",
    modalTitle:"Before you start",
    modalSub:"Tell us who's learning — this helps EasyPy save your progress and send you new lessons.",
    nameLabel:"Your name",
    emailLabel:"Email",
    namePh:"e.g. Swastik",
    emailPh:"you@example.com",
    submit:"Start learning →",
    skip:"Skip for now",
    adLabel:"Sponsored",
    adText:"Your ad or sponsor slot goes here once EasyPy is live on its own domain."
  },
  hi: {
    heroTitle:"पायथन सीखो, जैसे बोलना सीखा था।",
    heroSub:"बोलना सीखने से पहले किसी ने आपको व्याकरण की किताब नहीं दी थी। आपने इशारा किया, दोहराया, कोशिश की, और किसी ने मुस्कुरा कर ठीक किया। EasyPy पायथन भी वैसे ही सिखाता है — एक बार में एक छोटी, असली आदत।",
    heroCta:"पहला पाठ शुरू करें →",
    done:"पूरे",
    motherLabel:"आप जैसे कहते हैं",
    pythonLabel:"पायथन जैसे कहता है",
    codeTag:"यह कोड आज़माएं",
    predictLabel:"चलाने से पहले — आपको क्या लगता है यह क्या प्रिंट करेगा?",
    predictPh:"अपना अंदाज़ा यहाँ टाइप करें (वैकल्पिक)...",
    revealBtn:"असली आउटपुट देखें",
    actualOutput:"असली आउटपुट",
    quizHeading:"खुद जांच लें",
    correct:"सही जवाब — समझ गए।",
    wrong:"बिल्कुल सही नहीं। ब्रिज कार्ड फिर से देखें और एक बार और कोशिश करें।",
    prev:"← पिछला",
    next:"अगला पाठ →",
    finishTitle:"आपने सभी पाठ पूरे कर लिए 🎉",
    finishSub:"सच में — यह असली पायथन है, और सीखा भी वैसे ही गया जैसे कोई भाषा सीखी जाती है: उपयोग करके, नियम याद करके नहीं। अब कुछ छोटा, थोड़ा गड़बड़ वाला कोड खुद लिखकर देखें।",
    restart:"पाठ फिर से देखें",
    downloadCert:"अपना सर्टिफिकेट डाउनलोड करें",
    lessonWord:"पाठ",
    modalTitle:"शुरू करने से पहले",
    modalSub:"बताएं कि कौन सीख रहा है — इससे EasyPy आपकी प्रोग्रेस सेव कर सकता है और नए पाठ भेज सकता है।",
    nameLabel:"आपका नाम",
    emailLabel:"ईमेल",
    namePh:"जैसे स्वस्तिक",
    emailPh:"you@example.com",
    submit:"सीखना शुरू करें →",
    skip:"अभी छोड़ें",
    adLabel:"स्पॉन्सर्ड",
    adText:"EasyPy अपने डोमेन पर लाइव होने के बाद आपका विज्ञापन या स्पॉन्सर यहाँ आएगा।"
  },
  mr: {
    heroTitle:"पायथन शिका, जसे लहानपणी बोलायला शिकला होता.",
    heroSub:"बोलायला शिकण्याआधी कोणीही तुम्हाला व्याकरणाचे पुस्तक दिले नव्हते. तुम्ही बोट दाखवले, पुन्हा म्हणाले, प्रयत्न केला, आणि कोणीतरी हसून बरोबर केले. EasyPy पायथन देखील तसंच शिकवतो — एका वेळेस एक छोटी, खरी सवय.",
    heroCta:"पहिला पाठ सुरू करा →",
    done:"पूर्ण",
    motherLabel:"तुम्ही जसे म्हणता",
    pythonLabel:"पायथन जसे म्हणतो",
    codeTag:"हा कोड करून पाहा",
    predictLabel:"चालवण्याआधी — तुम्हाला काय वाटतं हे काय प्रिंट करेल?",
    predictPh:"तुमचा अंदाज इथे टाइप करा (ऐच्छिक)...",
    revealBtn:"खरा आउटपुट पाहा",
    actualOutput:"खरा आउटपुट",
    quizHeading:"स्वतः तपासा",
    correct:"बरोबर उत्तर — समजले तुम्हाला.",
    wrong:"बरोबर नाही. ब्रिज कार्ड पुन्हा पाहा आणि एकदा पुन्हा प्रयत्न करा.",
    prev:"← आधीचा",
    next:"पुढचा पाठ →",
    finishTitle:"तुम्ही सगळे पाठ पूर्ण केले 🎉",
    finishSub:"खरोखर — ही खरी पायथन आहे, आणि ती शिकली गेली जशी कोणतीही भाषा शिकली जाते: वापरून, नियम पाठ करून नाही. आता स्वतः काहीतरी छोटी, थोडी गोंधळ करणारी कोड लिहून बघा.",
    restart:"पाठ पुन्हा पाहा",
    downloadCert:"तुमचं सर्टिफिकेट डाउनलोड करा",
    lessonWord:"पाठ",
    modalTitle:"सुरू करण्याआधी",
    modalSub:"सांगा कोण शिकत आहे — यामुळे EasyPy तुमची प्रोग्रेस सेव्ह करू शकतो आणि नवीन पाठ पाठवू शकतो.",
    nameLabel:"तुमचं नाव",
    emailLabel:"ईमेल",
    namePh:"उदा. स्वस्तिक",
    emailPh:"you@example.com",
    submit:"शिकायला सुरुवात करा →",
    skip:"आता वगळा",
    adLabel:"स्पॉन्सर्ड",
    adText:"EasyPy स्वतःच्या डोमेनवर लाइव्ह झाल्यावर तुमची जाहिरात किंवा स्पॉन्सर इथे येईल."
  }
};

const LESSONS = [
  {key:"intro",
    en:{title:"Why Python feels like a language, not a subject",
      motherSide:"\u201CMy name is Swastik.\u201D — the first sentence any child says.",
      pythonSide:"name = \u201CSwastik\u201D — the first sentence any Python programmer writes.",
      explain:"Every language starts the same way: you name things. When you learnt Hindi or Marathi, the first words were nouns — 'maa', 'ghar', 'paani'. Python starts identically. A program is just a long conversation where you keep naming things and telling the computer what to do with them. There's no trick here, only the same habit you already have.",
      code:"# This is a comment — Python ignores it, it's just a note to humans\nname = \"Swastik\"\nprint(\"Hello,\", name)",
      output:"Hello, Swastik",
      quiz:[
        {q:"What does the line starting with # do?", opts:["Runs twice as fast","Is ignored by Python — it's a note for humans","Deletes the next line"], a:1},
        {q:"print() is used to...", opts:["Store a value","Show something on screen","Delete a variable"], a:1}]},
    hi:{title:"पायथन एक भाषा जैसा क्यों लगता है, विषय जैसा नहीं",
      motherSide:"\u201Cमेरा नाम स्वस्तिक है।\u201D — हर बच्चे का पहला वाक्य।",
      pythonSide:"name = \u201CSwastik\u201D — हर पायथन प्रोग्रामर का पहला वाक्य।",
      explain:"हर भाषा एक ही तरीके से शुरू होती है: पहले चीज़ों को नाम देना। जब आपने हिंदी या मराठी सीखी थी, तब पहले शब्द नाम ही थे — 'माँ', 'घर', 'पानी'। पायथन भी बिल्कुल वैसे ही शुरू होता है। एक प्रोग्राम बस एक लंबी बातचीत है जिसमें आप चीज़ों को नाम देते रहते हैं और कंप्यूटर को बताते हैं कि उनके साथ क्या करना है। यहाँ कोई ट्रिक नहीं है, सिर्फ वही आदत जो आपके पास पहले से है।",
      code:"# यह एक कमेंट है — पायथन इसे नज़रअंदाज़ करता है, यह सिर्फ इंसानों के लिए नोट है\nname = \"Swastik\"\nprint(\"नमस्ते,\", name)",
      output:"नमस्ते, Swastik",
      quiz:[
        {q:"# से शुरू होने वाली लाइन क्या करती है?", opts:["दो गुना तेज़ चलती है","पायथन इसे नज़रअंदाज़ करता है — यह सिर्फ नोट है","अगली लाइन को डिलीट कर देती है"], a:1},
        {q:"print() का काम क्या है?", opts:["वैल्यू स्टोर करना","स्क्रीन पर कुछ दिखाना","वेरिएबल डिलीट करना"], a:1}]},
    mr:{title:"पायथन भाषेसारखा का वाटतो, विषयासारखा नाही",
      motherSide:"\u201Cमाझं नाव स्वस्तिक आहे.\u201D — प्रत्येक मुलाचं पहिलं वाक्य.",
      pythonSide:"name = \u201CSwastik\u201D — प्रत्येक पायथन प्रोग्रामरचं पहिलं वाक्य.",
      explain:"प्रत्येक भाषा एकाच पद्धतीने सुरू होते: आधी गोष्टींना नाव देणे. जेव्हा तुम्ही मराठी शिकलात, तेव्हा पहिले शब्द नावंच होते — 'आई', 'घर', 'पाणी'. पायथन देखील तसाच सुरू होतो. एक प्रोग्राम म्हणजे फक्त एक लांब गप्पा आहे ज्यात तुम्ही गोष्टींना नाव देत राहता आणि संगणकाला सांगता की त्यांच्यासोबत काय करायचं. इथे कोणतीही ट्रिक नाही, फक्त तीच सवय जी तुमच्याकडे आधीच आहे.",
      code:"# हा एक कमेंट आहे — पायथन याकडे दुर्लक्ष करतो, हे फक्त माणसांसाठी टिप्पणी आहे\nname = \"Swastik\"\nprint(\"नमस्कार,\", name)",
      output:"नमस्कार, Swastik",
      quiz:[
        {q:"# ने सुरू होणारी ओळ काय करते?", opts:["दुप्पट वेगाने चालते","पायथन याकडे दुर्लक्ष करतो — हे फक्त टिप्पणी आहे","पुढची ओळ डिलीट करते"], a:1},
        {q:"print() चा उपयोग कशासाठी होतो?", opts:["व्हॅल्यू स्टोअर करण्यासाठी","स्क्रीनवर काही दाखवण्यासाठी","व्हेरिएबल डिलीट करण्यासाठी"], a:1}]}
  },
  {key:"variables",
    en:{title:"Variables — the nouns of Python",
      motherSide:"\u201CThat is my bag.\u201D — you point, then you name it.",
      pythonSide:"bag = \u201Cblue rexine\u201D — Python points and names it too.",
      explain:"A variable is just a box with a label. When a toddler learns 'bag' means that specific object, they're doing exactly what a variable does — attaching a name to a thing so you can talk about it later without pointing again. In Python, you write name = value, and from then on, the name carries the value everywhere.",
      code:"age = 21\ncity = \"Malegaon\"\nis_learning = True\n\nprint(city, age, is_learning)",
      output:"Malegaon 21 True",
      quiz:[
        {q:"In age = 21, what is 'age'?", opts:["A value","A variable name","A comment"], a:1},
        {q:"Which of these is a valid variable name?", opts:["2city","city2","city name"], a:1}]},
    hi:{title:"वेरिएबल्स — पायथन के 'नाम' (nouns)",
      motherSide:"\u201Cयह मेरा बैग है।\u201D — पहले इशारा, फिर नाम।",
      pythonSide:"bag = \u201Cनीला रेक्सिन\u201D — पायथन भी इशारा करता है और नाम देता है।",
      explain:"वेरिएबल बस एक डिब्बा है जिसपर लेबल लगा हो। जब कोई बच्चा सीखता है कि 'बैग' उस खास चीज़ को कहते हैं, तो वह ठीक वही कर रहा होता है जो वेरिएबल करता है — किसी चीज़ को नाम देना ताकि बाद में दोबारा इशारा किए बिना उसके बारे में बात कर सकें। पायथन में आप लिखते हैं name = value, और उसके बाद वह नाम हर जगह उस वैल्यू को साथ लेकर चलता है।",
      code:"age = 21\ncity = \"Malegaon\"\nis_learning = True\n\nprint(city, age, is_learning)",
      output:"Malegaon 21 True",
      quiz:[
        {q:"age = 21 में 'age' क्या है?", opts:["एक वैल्यू","एक वेरिएबल का नाम","एक कमेंट"], a:1},
        {q:"इनमें से कौन सा सही वेरिएबल नाम है?", opts:["2city","city2","city name"], a:1}]},
    mr:{title:"व्हेरिएबल्स — पायथनची 'नावं' (nouns)",
      motherSide:"\u201Cही माझी बॅग आहे.\u201D — आधी बोट दाखवणं, नंतर नाव.",
      pythonSide:"bag = \u201Cनिळी रेक्झिन\u201D — पायथन देखील बोट दाखवतो आणि नाव देतो.",
      explain:"व्हेरिएबल म्हणजे फक्त एक डबा ज्यावर लेबल लावलेलं आहे. जेव्हा एखादं मूल शिकतं की 'बॅग' त्या खास वस्तूला म्हणतात, तेव्हा तो नेमकं तेच करत असतो जे व्हेरिएबल करतं — एखाद्या गोष्टीला नाव देणं जेणेकरून पुन्हा बोट न दाखवता तिच्याबद्दल बोलता येईल. पायथनमध्ये तुम्ही लिहिता name = value, आणि त्यानंतर ते नाव सगळीकडे ती व्हॅल्यू सोबत घेऊन जातं.",
      code:"age = 21\ncity = \"Malegaon\"\nis_learning = True\n\nprint(city, age, is_learning)",
      output:"Malegaon 21 True",
      quiz:[
        {q:"age = 21 मध्ये 'age' काय आहे?", opts:["एक व्हॅल्यू","एक व्हेरिएबलचं नाव","एक कमेंट"], a:1},
        {q:"यापैकी योग्य व्हेरिएबल नाव कोणते?", opts:["2city","city2","city name"], a:1}]}
  },
  {key:"datatypes",
    en:{title:"Data types — words, numbers, and yes/no",
      motherSide:"\u201Cpaanch\u201D is a number, \u201Cpaani\u201D is a word, \u201Chaan/nahi\u201D is a yes/no.",
      pythonSide:"5 is int, \u201Cpaani\u201D is str, True/False is bool.",
      explain:"You already sort words into number-words, naming-words, and yes/no-words without thinking about it — that's grammar you absorbed as a kid. Python sorts its values the same way: int for whole numbers, float for decimals, str for text (always in quotes), and bool for True/False. The computer needs the type spelled out because, unlike you, it can't guess from context.",
      code:"marks = 95        # int\nprice = 49.5      # float\ncity = \"Nashik\"    # str\npassed = True      # bool\n\nprint(type(marks), type(price), type(city), type(passed))",
      output:"<class 'int'> <class 'float'> <class 'str'> <class 'bool'>",
      quiz:[
        {q:"49.5 belongs to which type?", opts:["int","float","str"], a:1},
        {q:"Why is \"Nashik\" written with quotes?", opts:["To make it a number","To mark it as text (str)","Quotes are optional decoration"], a:1}]},
    hi:{title:"डेटा टाइप्स — शब्द, अंक, और हाँ/नहीं",
      motherSide:"\u201Cपाँच\u201D एक अंक है, \u201Cपानी\u201D एक शब्द है, \u201Cहाँ/नहीं\u201D एक जवाब है।",
      pythonSide:"5 है int, \u201Cपानी\u201D है str, True/False है bool।",
      explain:"आप बिना सोचे-समझे शब्दों को अंक-शब्द, नाम-शब्द, और हाँ/नहीं-शब्द में बाँट लेते हैं — यह व्याकरण आपने बचपन में ही सीख ली थी। पायथन भी अपनी वैल्यूज़ को वैसे ही बाँटता है: पूरे नंबर के लिए int, दशमलव के लिए float, टेक्स्ट के लिए str (हमेशा कोट्स में), और True/False के लिए bool। कंप्यूटर को टाइप साफ-साफ बताना पड़ता है क्योंकि वह, आपकी तरह, संदर्भ से अंदाज़ा नहीं लगा सकता।",
      code:"marks = 95        # int\nprice = 49.5      # float\ncity = \"Nashik\"    # str\npassed = True      # bool\n\nprint(type(marks), type(price), type(city), type(passed))",
      output:"<class 'int'> <class 'float'> <class 'str'> <class 'bool'>",
      quiz:[
        {q:"49.5 किस टाइप में आता है?", opts:["int","float","str"], a:1},
        {q:"\"Nashik\" को कोट्स में क्यों लिखा है?", opts:["इसे नंबर बनाने के लिए","इसे टेक्स्ट (str) बताने के लिए","कोट्स सिर्फ सजावट हैं"], a:1}]},
    mr:{title:"डेटा टाइप्स — शब्द, आकडे, आणि होय/नाही",
      motherSide:"\u201Cपाच\u201D हा आकडा आहे, \u201Cपाणी\u201D हा शब्द आहे, \u201Cहोय/नाही\u201D हे उत्तर आहे.",
      pythonSide:"5 म्हणजे int, \u201Cपाणी\u201D म्हणजे str, True/False म्हणजे bool.",
      explain:"तुम्ही आधीच शब्दांना आकडे-शब्द, नाव-शब्द, आणि होय/नाही-शब्द यांत विभागता, काहीही विचार न करता — ही व्याकरण तुम्ही लहानपणीच शिकला होता. पायथन देखील त्याच्या व्हॅल्यूज तशाच विभागतो: पूर्ण संख्येसाठी int, दशांशासाठी float, मजकुरासाठी str (नेहमी कोट्समध्ये), आणि True/False साठी bool. संगणकाला टाइप स्पष्टपणे सांगावा लागतो कारण त्याला, तुमच्यासारखं, संदर्भावरून अंदाज लावता येत नाही.",
      code:"marks = 95        # int\nprice = 49.5      # float\ncity = \"Nashik\"    # str\npassed = True      # bool\n\nprint(type(marks), type(price), type(city), type(passed))",
      output:"<class 'int'> <class 'float'> <class 'str'> <class 'bool'>",
      quiz:[
        {q:"49.5 कोणत्या टाइपमध्ये येतो?", opts:["int","float","str"], a:1},
        {q:"\"Nashik\" कोट्समध्ये का लिहिलं आहे?", opts:["त्याला नंबर बनवण्यासाठी","त्याला मजकूर (str) दाखवण्यासाठी","कोट्स फक्त सजावट आहेत"], a:1}]}
  },
  {key:"iotalk",
    en:{title:"print() and input() — the two-way conversation",
      motherSide:"You ask \u201CWhat time is it?\u201D, someone answers.",
      pythonSide:"input() asks, print() answers back.",
      explain:"A real conversation goes both ways — you ask, they reply. print() is Python speaking to you. input() is Python listening to you. Whatever a person types into input() always arrives as text (str), even if it looks like a number, so you often need int() to convert it before doing maths with it.",
      code:"name = input(\"What's your name? \")\nage = int(input(\"Your age? \"))\n\nprint(\"Hello,\", name, \"— you are\", age, \"years old.\")",
      output:"Hello, Riya — you are 19 years old.",
      quiz:[
        {q:"What does input() always return, before any conversion?", opts:["An int","A str (text)","A bool"], a:1},
        {q:"Why wrap input() in int() for age?", opts:["To make it look neat","Because input() gives text, and math needs numbers","It's optional and does nothing"], a:1}]},
    hi:{title:"print() और input() — दो-तरफा बातचीत",
      motherSide:"आप पूछते हैं \u201Cकितने बजे हैं?\u201D, कोई जवाब देता है।",
      pythonSide:"input() पूछता है, print() जवाब देता है।",
      explain:"एक असली बातचीत दोनों तरफ होती है — आप पूछते हैं, वे जवाब देते हैं। print() पायथन का आपसे बोलना है। input() पायथन का आपको सुनना है। इंसान input() में जो भी टाइप करे, वह हमेशा टेक्स्ट (str) की तरह आता है, चाहे वह नंबर जैसा ही लगे, इसलिए गणित करने से पहले उसे int() से बदलना पड़ता है।",
      code:"name = input(\"आपका नाम? \")\nage = int(input(\"आपकी उम्र? \"))\n\nprint(\"नमस्ते,\", name, \"— आप\", age, \"साल के हैं।\")",
      output:"नमस्ते, Riya — आप 19 साल के हैं।",
      quiz:[
        {q:"input() बिना किसी बदलाव के हमेशा क्या देता है?", opts:["एक int","एक str (टेक्स्ट)","एक bool"], a:1},
        {q:"उम्र के लिए input() को int() में क्यों लपेटते हैं?", opts:["सिर्फ साफ दिखने के लिए","क्योंकि input() टेक्स्ट देता है, और गणित के लिए नंबर चाहिए","इससे कोई फर्क नहीं पड़ता"], a:1}]},
    mr:{title:"print() आणि input() — दुतर्फी गप्पा",
      motherSide:"तुम्ही विचारता \u201Cकिती वाजले?\u201D, कोणी उत्तर देतं.",
      pythonSide:"input() विचारतो, print() उत्तर देतो.",
      explain:"खरी गप्पा दोन्ही बाजूला होते — तुम्ही विचारता, ते उत्तर देतात. print() म्हणजे पायथन तुमच्याशी बोलतो. input() म्हणजे पायथन तुमचं ऐकतो. माणसाने input() मध्ये जे काही टाइप केलं, ते नेहमी मजकूर (str) सारखं येतं, मग ते आकड्यासारखं दिसलं तरी, म्हणून गणित करण्याआधी त्याला int() ने बदलावं लागतं.",
      code:"name = input(\"तुमचं नाव? \")\nage = int(input(\"तुमचं वय? \"))\n\nprint(\"नमस्कार,\", name, \"— तुम्ही\", age, \"वर्षांचे आहात.\")",
      output:"नमस्कार, Riya — तुम्ही 19 वर्षांचे आहात.",
      quiz:[
        {q:"input() कोणताही बदल न करता नेहमी काय देतो?", opts:["एक int","एक str (मजकूर)","एक bool"], a:1},
        {q:"वयासाठी input() ला int() मध्ये का गुंडाळतात?", opts:["फक्त नीट दिसण्यासाठी","कारण input() मजकूर देतो, आणि गणितासाठी आकडे लागतात","याचा काहीही फरक पडत नाही"], a:1}]}
  },
  {key:"conditionals",
    en:{title:"if / else — the way you already decide things",
      motherSide:"\u201CIf the water is hot, make chai, else drink it cold.\u201D",
      pythonSide:"if temp > 60: make_chai() / else: drink_cold()",
      explain:"You never decide anything without a condition — 'if it's raining, take an umbrella'. Python's if/else is the exact same sentence structure, just written strictly: if a condition is True, run this block; else, run that one. Indentation (the spaces at the start of a line) is how Python knows which lines belong inside the 'if'.",
      code:"marks = 78\n\nif marks >= 90:\n    print(\"A grade\")\nelif marks >= 60:\n    print(\"B grade\")\nelse:\n    print(\"Keep practising\")",
      output:"B grade",
      quiz:[
        {q:"What decides which block runs?", opts:["The order lines were typed","Whether the condition is True or False","The length of the code"], a:1},
        {q:"What is elif short for?", opts:["'else if' — another condition to check","'end if' — stops the block","Nothing, it's decoration"], a:0}]},
    hi:{title:"if / else — जैसे आप पहले से ही फैसला लेते हैं",
      motherSide:"\u201Cअगर पानी गरम है, तो चाय बना लो, वरना ठंडा पी लो।\u201D",
      pythonSide:"if temp > 60: make_chai() / else: drink_cold()",
      explain:"आप कभी भी बिना शर्त के फैसला नहीं लेते — 'अगर बारिश हो रही है, तो छतरी ले लो'। पायथन का if/else बिल्कुल वही वाक्य-ढांचा है, सिर्फ सख्ती से लिखा गया: अगर शर्त True है, तो यह ब्लॉक चलाओ; वरना, वह ब्लॉक चलाओ। इंडेंटेशन (लाइन की शुरुआत में खाली जगह) से पायथन को पता चलता है कि कौन सी लाइनें 'if' के अंदर आती हैं।",
      code:"marks = 78\n\nif marks >= 90:\n    print(\"A ग्रेड\")\nelif marks >= 60:\n    print(\"B ग्रेड\")\nelse:\n    print(\"अभ्यास करते रहो\")",
      output:"B ग्रेड",
      quiz:[
        {q:"कौन सा ब्लॉक चलेगा, यह क्या तय करता है?", opts:["लाइनें किस क्रम में टाइप हुई","शर्त True है या False","कोड कितना लंबा है"], a:1},
        {q:"elif का पूरा मतलब क्या है?", opts:["'else if' — एक और शर्त जांचना","'end if' — ब्लॉक को रोक देना","कुछ नहीं, सिर्फ सजावट है"], a:0}]},
    mr:{title:"if / else — जसे तुम्ही आधीच निर्णय घेता",
      motherSide:"\u201Cजर पाणी गरम असेल, तर चहा बनवा, नाहीतर थंड प्या.\u201D",
      pythonSide:"if temp > 60: make_chai() / else: drink_cold()",
      explain:"तुम्ही कधीही अटीशिवाय निर्णय घेत नाही — 'जर पाऊस पडत असेल, तर छत्री घेऊन जा'. पायथनचा if/else अगदी तीच वाक्यरचना आहे, फक्त काटेकोरपणे लिहिलेली: जर अट True असेल, तर हा ब्लॉक चालवा; नाहीतर, तो ब्लॉक चालवा. इंडेंटेशन (ओळीच्या सुरुवातीची रिकामी जागा) मुळे पायथनला समजतं कोणत्या ओळी 'if' च्या आत येतात.",
      code:"marks = 78\n\nif marks >= 90:\n    print(\"A ग्रेड\")\nelif marks >= 60:\n    print(\"B ग्रेड\")\nelse:\n    print(\"सराव करत राहा\")",
      output:"B ग्रेड",
      quiz:[
        {q:"कोणता ब्लॉक चालेल, हे काय ठरवतं?", opts:["ओळी कोणत्या क्रमाने टाइप झाल्या","अट True आहे की False","कोड किती मोठा आहे"], a:1},
        {q:"elif चा पूर्ण अर्थ काय आहे?", opts:["'else if' — आणखी एक अट तपासणे","'end if' — ब्लॉक थांबवणे","काहीही नाही, फक्त सजावट आहे"], a:0}]}
  },
  {key:"loops",
    en:{title:"Loops — saying the same thing till it's done",
      motherSide:"\u201CBrush your teeth, brush your teeth, brush your teeth\u201D — repeated till it's finished.",
      pythonSide:"for i in range(3): print(\"brush now\")",
      explain:"You already repeat instructions until a job is done — that's a loop, spoken out loud. Python's for loop repeats an action a set number of times or over a list of items; while repeats as long as a condition stays True. Loops exist because computers are patient with repetition in a way people aren't — they'll happily do the same thing a thousand times without complaining.",
      code:"for i in range(1, 4):\n    print(\"Round\", i, \"— brush now!\")\n\ncount = 0\nwhile count < 3:\n    print(\"Still going:\", count)\n    count = count + 1",
      output:"Round 1 — brush now!\nRound 2 — brush now!\nRound 3 — brush now!\nStill going: 0\nStill going: 1\nStill going: 2",
      quiz:[
        {q:"range(1, 4) produces which numbers?", opts:["1, 2, 3, 4","1, 2, 3","0, 1, 2, 3"], a:1},
        {q:"A while loop keeps running as long as...", opts:["The variable is named 'count'","Its condition stays True","Python feels like it"], a:1}]},
    hi:{title:"लूप्स — जब तक काम हो न जाए, वही बात दोहराना",
      motherSide:"\u201Cबेटा, ब्रश कर, ब्रश कर, ब्रश कर\u201D — जब तक खत्म न हो।",
      pythonSide:"for i in range(3): print(\"ब्रश कर\")",
      explain:"आप पहले से ही निर्देश दोहराते हैं जब तक काम पूरा न हो जाए — यही लूप है, बस बोलकर। पायथन का for लूप किसी काम को एक तय संख्या में या लिस्ट के हर आइटम पर दोहराता है; while तब तक दोहराता है जब तक शर्त True रहे। लूप्स इसलिए हैं क्योंकि कंप्यूटर दोहराव में उतना ही धैर्यवान रहता है जितना इंसान नहीं रह सकता — वह बिना शिकायत किए एक ही काम हज़ार बार कर देगा।",
      code:"for i in range(1, 4):\n    print(\"राउंड\", i, \"— ब्रश कर!\")\n\ncount = 0\nwhile count < 3:\n    print(\"अभी चल रहा है:\", count)\n    count = count + 1",
      output:"राउंड 1 — ब्रश कर!\nराउंड 2 — ब्रश कर!\nराउंड 3 — ब्रश कर!\nअभी चल रहा है: 0\nअभी चल रहा है: 1\nअभी चल रहा है: 2",
      quiz:[
        {q:"range(1, 4) कौन से नंबर देता है?", opts:["1, 2, 3, 4","1, 2, 3","0, 1, 2, 3"], a:1},
        {q:"while लूप तब तक चलता रहता है जब तक...", opts:["वेरिएबल का नाम 'count' हो","उसकी शर्त True रहे","पायथन का मन करे"], a:1}]},
    mr:{title:"लूप्स — काम होईपर्यंत तेच सांगत राहणं",
      motherSide:"\u201Cबाळा, ब्रश कर, ब्रश कर, ब्रश कर\u201D — काम संपेपर्यंत.",
      pythonSide:"for i in range(3): print(\"ब्रश कर\")",
      explain:"तुम्ही आधीच सूचना पुन्हा पुन्हा सांगता जोपर्यंत काम पूर्ण होत नाही — हाच लूप आहे, फक्त बोलून. पायथनचा for लूप कोणत्याही कामाला एका ठराविक वेळेस किंवा लिस्टमधल्या प्रत्येक आयटमवर पुन्हा करतो; while तोपर्यंत पुन्हा करतो जोपर्यंत अट True राहते. लूप्स असतात कारण संगणक पुनरावृत्तीमध्ये इतका पेशंट राहतो जितका माणूस राहू शकत नाही — तो कोणतीही तक्रार न करता एकच काम हजार वेळा करेल.",
      code:"for i in range(1, 4):\n    print(\"राउंड\", i, \"— ब्रश कर!\")\n\ncount = 0\nwhile count < 3:\n    print(\"अजून चालू आहे:\", count)\n    count = count + 1",
      output:"राउंड 1 — ब्रश कर!\nराउंड 2 — ब्रश कर!\nराउंड 3 — ब्रश कर!\nअजून चालू आहे: 0\nअजून चालू आहे: 1\nअजून चालू आहे: 2",
      quiz:[
        {q:"range(1, 4) कोणते आकडे देतो?", opts:["1, 2, 3, 4","1, 2, 3","0, 1, 2, 3"], a:1},
        {q:"while लूप तोपर्यंत चालत राहतो जोपर्यंत...", opts:["व्हेरिएबलचं नाव 'count' असेल","त्याची अट True राहते","पायथनचं मन होईल"], a:1}]}
  },
  {key:"lists",
    en:{title:"Lists — a shopping list Python can actually use",
      motherSide:"\u201Cmilk, tea leaves, sugar\u201D — one list, several items.",
      pythonSide:"items = [\"milk\", \"tea leaves\", \"sugar\"]",
      explain:"You've written a shopping list a hundred times — a single named thing holding several items in order. A Python list does exactly that: square brackets, items separated by commas. You reach any item by its position, starting from 0 — the first item is index 0, not 1, because Python counts 'how far from the start' rather than 'which number in line'.",
      code:"items = [\"milk\", \"tea leaves\", \"sugar\"]\n\nprint(items[0])      # first item\nitems.append(\"biscuits\")\nprint(items)\nprint(len(items))    # how many items",
      output:"milk\n['milk', 'tea leaves', 'sugar', 'biscuits']\n4",
      quiz:[
        {q:"items[0] refers to which item?", opts:["The last item","The first item","An empty item"], a:1},
        {q:"What does .append() do?", opts:["Removes an item","Adds an item to the end","Counts the items"], a:1}]},
    hi:{title:"लिस्ट्स — एक शॉपिंग लिस्ट जो पायथन समझ सकता है",
      motherSide:"\u201Cदूध, चाय पत्ती, चीनी\u201D — एक लिस्ट, कई आइटम।",
      pythonSide:"items = [\"दूध\", \"चाय पत्ती\", \"चीनी\"]",
      explain:"आप सौ बार शॉपिंग लिस्ट बना चुके हैं — एक नाम वाली चीज़ जिसमें कई आइटम क्रम से रखे हैं। पायथन लिस्ट भी ठीक वही करती है: स्क्वेयर ब्रैकेट्स, आइटम कॉमा से अलग। आप किसी भी आइटम तक उसकी पोज़िशन से पहुँचते हैं, 0 से शुरू — पहला आइटम इंडेक्स 0 होता है, 1 नहीं, क्योंकि पायथन 'शुरुआत से कितनी दूर' गिनता है, 'लाइन में कौन सा नंबर' नहीं।",
      code:"items = [\"दूध\", \"चाय पत्ती\", \"चीनी\"]\n\nprint(items[0])      # पहला आइटम\nitems.append(\"बिस्किट\")\nprint(items)\nprint(len(items))    # कितने आइटम हैं",
      output:"दूध\n['दूध', 'चाय पत्ती', 'चीनी', 'बिस्किट']\n4",
      quiz:[
        {q:"items[0] कौन सा आइटम बताता है?", opts:["आखिरी आइटम","पहला आइटम","खाली आइटम"], a:1},
        {q:".append() क्या करता है?", opts:["एक आइटम हटाता है","एक आइटम आखिर में जोड़ता है","आइटम्स गिनता है"], a:1}]},
    mr:{title:"लिस्ट्स — एक शॉपिंग लिस्ट जी पायथन समजू शकतो",
      motherSide:"\u201Cदूध, चहा पावडर, साखर\u201D — एक लिस्ट, अनेक आयटम.",
      pythonSide:"items = [\"दूध\", \"चहा पावडर\", \"साखर\"]",
      explain:"तुम्ही शंभर वेळा शॉपिंग लिस्ट बनवली आहे — एक नाव असलेली गोष्ट ज्यात अनेक आयटम क्रमाने ठेवलेले आहेत. पायथन लिस्ट देखील नेमकं तेच करते: स्क्वेअर ब्रॅकेट्स, आयटम कॉम्याने वेगळे. तुम्ही कोणत्याही आयटमपर्यंत त्याच्या पोझिशनने पोहोचता, 0 पासून सुरू — पहिला आयटम इंडेक्स 0 असतो, 1 नाही, कारण पायथन 'सुरुवातीपासून किती दूर' मोजतो, 'ओळीत कोणता नंबर' नाही.",
      code:"items = [\"दूध\", \"चहा पावडर\", \"साखर\"]\n\nprint(items[0])      # पहिला आयटम\nitems.append(\"बिस्किट\")\nprint(items)\nprint(len(items))    # किती आयटम आहेत",
      output:"दूध\n['दूध', 'चहा पावडर', 'साखर', 'बिस्किट']\n4",
      quiz:[
        {q:"items[0] कोणता आयटम दाखवतो?", opts:["शेवटचा आयटम","पहिला आयटम","रिकामा आयटम"], a:1},
        {q:".append() काय करतो?", opts:["एक आयटम काढतो","एक आयटम शेवटी जोडतो","आयटम मोजतो"], a:1}]}
  },
  {key:"functions",
    en:{title:"Functions — a habit you can call by name",
      motherSide:"\u201CSay namaste\u201D — a whole ritual triggered by one phrase.",
      pythonSide:"def greet(): print(\"Namaste!\")",
      explain:"'Say namaste' isn't one action, it's a whole learnt sequence — join palms, bow slightly, say the word — triggered by a short instruction. A function packages a sequence of steps under one name so you can trigger the whole thing again just by calling it, instead of retyping every step each time.",
      code:"def greet(name):\n    print(\"Namaste,\", name, \"!\")\n\ndef add(a, b):\n    return a + b\n\ngreet(\"Swastik\")\ntotal = add(4, 5)\nprint(\"Total:\", total)",
      output:"Namaste, Swastik !\nTotal: 9",
      quiz:[
        {q:"What keyword starts a function definition?", opts:["func","define","def"], a:2},
        {q:"What does return do inside a function?", opts:["Prints text on screen","Sends a value back to whoever called it","Deletes the function"], a:1}]},
    hi:{title:"फंक्शन्स — एक आदत जिसे नाम से बुलाया जा सके",
      motherSide:"\u201Cनमस्ते बोलो\u201D — एक पूरा रिवाज़ जो एक शब्द से शुरू होता है।",
      pythonSide:"def greet(): print(\"नमस्ते!\")",
      explain:"'नमस्ते बोलो' सिर्फ एक काम नहीं है, यह एक पूरा सीखा हुआ क्रम है — हाथ जोड़ो, थोड़ा झुको, शब्द बोलो — जो एक छोटे से निर्देश से शुरू होता है। फंक्शन भी चरणों के क्रम को एक नाम के अंदर रख देता है, ताकि आप हर बार सब कुछ दोबारा टाइप किए बिना, सिर्फ नाम से पूरी चीज़ चला सकें।",
      code:"def greet(name):\n    print(\"नमस्ते,\", name, \"!\")\n\ndef add(a, b):\n    return a + b\n\ngreet(\"Swastik\")\ntotal = add(4, 5)\nprint(\"कुल:\", total)",
      output:"नमस्ते, Swastik !\nकुल: 9",
      quiz:[
        {q:"फंक्शन डेफिनिशन कौन से कीवर्ड से शुरू होती है?", opts:["func","define","def"], a:2},
        {q:"फंक्शन के अंदर return क्या करता है?", opts:["स्क्रीन पर टेक्स्ट प्रिंट करता है","एक वैल्यू वापस भेजता है जिसने बुलाया था","फंक्शन को डिलीट कर देता है"], a:1}]},
    mr:{title:"फंक्शन्स — एक सवय जिला नावाने बोलावता येईल",
      motherSide:"\u201Cनमस्कार म्हणा\u201D — एक पूर्ण विधी जो एका शब्दाने सुरू होतो.",
      pythonSide:"def greet(): print(\"नमस्कार!\")",
      explain:"'नमस्कार म्हणा' फक्त एक काम नाही, ही एक पूर्ण शिकलेली क्रमवारी आहे — हात जोडा, थोडं वाकावं, शब्द म्हणा — जी एका छोट्या सूचनेने सुरू होते. फंक्शन देखील पायऱ्यांच्या क्रमाला एका नावाखाली ठेवतं, जेणेकरून तुम्ही प्रत्येक वेळेला परत सगळं टाइप न करता, फक्त नावाने पूर्ण गोष्ट चालवू शकता.",
      code:"def greet(name):\n    print(\"नमस्कार,\", name, \"!\")\n\ndef add(a, b):\n    return a + b\n\ngreet(\"Swastik\")\ntotal = add(4, 5)\nprint(\"एकूण:\", total)",
      output:"नमस्कार, Swastik !\nएकूण: 9",
      quiz:[
        {q:"फंक्शन डेफिनिशन कोणत्या कीवर्डने सुरू होते?", opts:["func","define","def"], a:2},
        {q:"फंक्शनच्या आत return काय करतो?", opts:["स्क्रीनवर मजकूर प्रिंट करतो","एक व्हॅल्यू परत पाठवतो ज्याने बोलावलं होतं","फंक्शन डिलीट करतो"], a:1}]}
  }
];

/* ---------------- storage abstraction (works in Claude artifact; degrades gracefully outside it) ---------------- */
const memoryFallback = {};
const safeStorage = {
  async get(key){
    try{
      if(window.storage && window.storage.get) return await window.storage.get(key);
    }catch(e){}
    return memoryFallback[key] ? {value:memoryFallback[key]} : null;
  },
  async set(key, value){
    try{
      if(window.storage && window.storage.set) return await window.storage.set(key, value);
    }catch(e){}
    memoryFallback[key] = value;
    return {key, value};
  }
};

/* ---------------- state ---------------- */
let state = {
  lang: "en",
  view: "home",
  progress: {},
  lead: null   // {name, email}
};

async function loadState(){
  try{
    const r = await safeStorage.get("easypy-state");
    if(r && r.value){
      const saved = JSON.parse(r.value);
      state.lang = saved.lang || "en";
      state.progress = saved.progress || {};
      state.lead = saved.lead || null;
    }
  }catch(e){}
}
async function saveState(){
  try{
    await safeStorage.set("easypy-state", JSON.stringify({lang:state.lang, progress:state.progress, lead:state.lead}));
  }catch(e){ console.error("save failed", e); }
}

function t(){ return UI[state.lang]; }

function renderLangTabs(){
  const wrap = document.getElementById("langtabs");
  const labels = {en:"EN", hi:"हिंदी", mr:"मराठी"};
  wrap.innerHTML = "";
  Object.keys(labels).forEach(code=>{
    const b = document.createElement("button");
    b.textContent = labels[code];
    if(state.lang === code) b.classList.add("active");
    b.onclick = ()=>{ state.lang = code; saveState(); renderAll(); };
    wrap.appendChild(b);
  });
}

function renderSidebar(){
  const nav = document.getElementById("sidebar");
  nav.innerHTML = "";

  const progresswrap = document.createElement("div");
  progresswrap.className = "progresswrap";
  const doneCount = Object.keys(state.progress).length;
  progresswrap.innerHTML = `
    <div class="progressbar"><div style="width:${(doneCount/LESSONS.length*100)}%"></div></div>
    <div class="progresslabel">${doneCount}/${LESSONS.length} ${t().done}</div>
  `;
  nav.appendChild(progresswrap);

  const navlist = document.createElement("div");
  navlist.className = "navlist";
  LESSONS.forEach((lesson, idx)=>{
    const item = document.createElement("button");
    item.className = "navitem" + (state.view===idx ? " active":"") + (state.progress[lesson.key] ? " done":"");
    const numSpan = state.progress[lesson.key] && state.view!==idx
      ? `<span class="num check"></span>`
      : `<span class="num">${idx+1}</span>`;
    item.innerHTML = `${numSpan}<span>${lesson[state.lang].title}</span>`;
    item.onclick = ()=>{ state.view = idx; renderAll(); window.scrollTo({top:0,behavior:"smooth"}); };
    navlist.appendChild(item);
  });
  nav.appendChild(navlist);

  const ad = document.createElement("div");
  ad.className = "adslot";
  // Once AdSense is approved, replace YOUR_ADSENSE_PUBLISHER_ID and
  // YOUR_ADSENSE_SLOT_ID below and uncomment the <ins> tag to show real ads.
  // Until then this simply shows a friendly placeholder.
  ad.innerHTML = `
    <div class="adlabel">${t().adLabel}</div>
    <div class="adtext">${t().adText}</div>
    <!--
    <ins class="adsbygoogle" style="display:block" data-ad-client="YOUR_ADSENSE_PUBLISHER_ID" data-ad-slot="YOUR_ADSENSE_SLOT_ID" data-ad-format="auto" data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
    -->
  `;
  nav.appendChild(ad);
}

function renderHome(){
  const m = document.getElementById("main");
  m.innerHTML = `
    <div class="hero">
      <h1>${t().heroTitle}</h1>
      <div class="sub">${t().heroSub}</div>
      <button class="hero cta" id="startBtn">${t().heroCta}</button>
    </div>
  `;
  document.getElementById("startBtn").onclick = ()=>{
    if(!state.lead){ showLeadModal(()=>{ state.view = 0; renderAll(); }); }
    else { state.view = 0; renderAll(); }
  };
}

function renderFinish(){
  const m = document.getElementById("main");
  m.innerHTML = `
    <div class="hero">
      <h1>${t().finishTitle}</h1>
      <div class="sub">${t().finishSub}</div>
      <button class="hero cta" id="restartBtn">${t().restart}</button>
    </div>
    <div class="certcard">
      <div style="font-size:13px;letter-spacing:0.08em;text-transform:uppercase;opacity:0.7;">EasyPy</div>
      <h2 style="margin:10px 0 4px;font-size:22px;">${(state.lead && state.lead.name) ? state.lead.name : "Python Learner"}</h2>
      <div style="font-size:13.5px;opacity:0.8;">completed all ${LESSONS.length} EasyPy lessons</div>
      <button class="certbtn" id="certBtn">${t().downloadCert}</button>
      <canvas id="certCanvas" width="1000" height="600"></canvas>
    </div>
  `;
  document.getElementById("restartBtn").onclick = ()=>{ state.view = 0; renderAll(); };
  document.getElementById("certBtn").onclick = ()=>drawAndDownloadCertificate();
}

function drawAndDownloadCertificate(){
  const canvas = document.getElementById("certCanvas");
  const ctx = canvas.getContext("2d");
  const learnerName = (state.lead && state.lead.name) ? state.lead.name : "Python Learner";

  // background
  ctx.fillStyle = "#FAF9F6";
  ctx.fillRect(0,0,1000,600);
  ctx.strokeStyle = "#D97757";
  ctx.lineWidth = 6;
  ctx.strokeRect(24,24,952,552);
  ctx.strokeStyle = "#E7E2D5";
  ctx.lineWidth = 1;
  ctx.strokeRect(40,40,920,520);

  ctx.fillStyle = "#15140F";
  ctx.textAlign = "center";
  ctx.font = "700 26px Inter, sans-serif";
  ctx.fillText("EasyPy", 500, 130);

  ctx.font = "600 15px Inter, sans-serif";
  ctx.fillStyle = "#6E6B62";
  ctx.textTransform = "uppercase";
  ctx.fillText("CERTIFICATE OF COMPLETION", 500, 165);

  ctx.font = "700 42px Inter, sans-serif";
  ctx.fillStyle = "#1F1E1B";
  ctx.fillText(learnerName, 500, 280);

  ctx.font = "400 17px Inter, sans-serif";
  ctx.fillStyle = "#6E6B62";
  ctx.fillText("has completed all " + LESSONS.length + " EasyPy lessons and learnt Python", 500, 330);
  ctx.fillText("the way a language is learnt — by using it.", 500, 358);

  const dateStr = new Date().toLocaleDateString(undefined, {year:"numeric", month:"long", day:"numeric"});
  ctx.font = "500 14px Inter, sans-serif";
  ctx.fillStyle = "#8A877D";
  ctx.fillText(dateStr, 500, 470);

  ctx.strokeStyle = "#D97757";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(400,440); ctx.lineTo(600,440);
  ctx.stroke();

  const link = document.createElement("a");
  link.download = "EasyPy-Certificate-" + learnerName.replace(/\s+/g,"_") + ".png";
  link.href = canvas.toDataURL("image/png");
  link.click();
}

function showLeadModal(onDone){
  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="modal-overlay" id="modalOverlay">
      <div class="modal">
        <h3>${t().modalTitle}</h3>
        <p>${t().modalSub}</p>
        <label>${t().nameLabel}</label>
        <input type="text" id="leadName" placeholder="${t().namePh}">
        <label>${t().emailLabel}</label>
        <input type="email" id="leadEmail" placeholder="${t().emailPh}">
        <button class="submitbtn" id="leadSubmit">${t().submit}</button>
        <button class="skipbtn" id="leadSkip">${t().skip}</button>
      </div>
    </div>
  `;
  document.getElementById("leadSubmit").onclick = ()=>{
    const name = document.getElementById("leadName").value.trim();
    const email = document.getElementById("leadEmail").value.trim();
    state.lead = {name, email};
    saveState();

    // FORMSPREE — sends the name/email to your inbox once this site is
    // hosted on your own domain. Replace YOUR_FORMSPREE_ID (get one free
    // at https://formspree.io) for this to actually deliver leads to you.
    try{
      const fd = new FormData();
      fd.append("name", name);
      fd.append("email", email);
      fd.append("language", state.lang);
      fetch("https://formspree.io/f/YOUR_FORMSPREE_ID", {
        method: "POST",
        headers: {"Accept":"application/json"},
        body: fd
      }).catch(()=>{});
    }catch(e){ /* Formspree not configured yet — safe to ignore */ }

    root.innerHTML = "";
    onDone();
  };
  document.getElementById("leadSkip").onclick = ()=>{
    root.innerHTML = "";
    onDone();
  };
}

function renderLesson(idx){
  const lesson = LESSONS[idx];
  const L = lesson[state.lang];
  const m = document.getElementById("main");

  const quizHtml = L.quiz.map((q, qi)=>`
    <div class="qblock" data-qi="${qi}">
      <div class="qtext">${qi+1}. ${q.q}</div>
      <div class="options">
        ${q.opts.map((opt,oi)=>`<button class="opt" data-oi="${oi}">${opt}</button>`).join("")}
      </div>
      <div class="feedback" style="display:none;"></div>
    </div>
  `).join("");

  m.innerHTML = `
    <div class="lesson-eyebrow">${t().lessonWord} ${idx+1} / ${LESSONS.length}</div>
    <h2 class="lesson-title">${L.title}</h2>

    <div class="bridge">
      <div class="side mother">
        <div class="label">${t().motherLabel}</div>
        <div class="content">${L.motherSide}</div>
      </div>
      <div class="arrow">→</div>
      <div class="side python">
        <div class="label">${t().pythonLabel}</div>
        <div class="content"><code>${escapeHtml(L.pythonSide)}</code></div>
      </div>
    </div>

    <div class="explain">${L.explain}</div>

    <div class="codecard">
      <button class="copybtn" id="copyBtn">Copy</button>
      <span class="tag">${t().codeTag}</span>${escapeHtml(L.code)}
    </div>

    <div class="predict">
      <div class="plabel">${t().predictLabel}</div>
      <textarea id="predictInput" placeholder="${t().predictPh}"></textarea>
      <button class="revealbtn" id="revealBtn">${t().revealBtn}</button>
      <div class="outputbox" id="outputBox"><span class="olabel">${t().actualOutput}</span>${escapeHtml(L.output || "")}</div>
    </div>

    <div class="quiz">
      <h3>${t().quizHeading}</h3>
      ${quizHtml}
    </div>

    <div class="navrow">
      <button class="btn ghost" id="prevBtn" ${idx===0 ? "disabled":""}>${t().prev}</button>
      <button class="btn primary" id="nextBtn">${t().next}</button>
    </div>
  `;

  document.getElementById("copyBtn").onclick = ()=>{
    const btn = document.getElementById("copyBtn");
    navigator.clipboard.writeText(L.code).then(()=>{
      btn.textContent = "Copied!";
      setTimeout(()=>{ btn.textContent = "Copy"; }, 1500);
    }).catch(()=>{});
  };

  document.getElementById("revealBtn").onclick = ()=>{
    document.getElementById("outputBox").style.display = "block";
  };

  m.querySelectorAll(".qblock").forEach((block, qi)=>{
    const q = L.quiz[qi];
    const buttons = block.querySelectorAll(".opt");
    const fb = block.querySelector(".feedback");
    buttons.forEach((btn, oi)=>{
      btn.onclick = ()=>{
        buttons.forEach(b=>b.disabled = true);
        if(oi === q.a){
          btn.classList.add("correct");
          fb.textContent = t().correct;
          fb.className = "feedback correct";
        }else{
          btn.classList.add("wrong");
          buttons[q.a].classList.add("correct");
          fb.textContent = t().wrong;
          fb.className = "feedback wrong";
        }
        fb.style.display = "block";
        state.progress[lesson.key] = true;
        saveState();
        renderSidebar();
      };
    });
  });

  document.getElementById("prevBtn").onclick = ()=>{
    state.view = idx===0 ? "home" : idx-1;
    renderAll(); window.scrollTo({top:0,behavior:"smooth"});
  };
  document.getElementById("nextBtn").onclick = ()=>{
    state.progress[lesson.key] = true;
    saveState();
    state.view = idx===LESSONS.length-1 ? "finish" : idx+1;
    renderAll(); window.scrollTo({top:0,behavior:"smooth"});
  };
}

function escapeHtml(str){
  return str.replace(/[&<>]/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
}

function renderAll(){
  renderLangTabs();
  renderSidebar();
  if(state.view === "home") renderHome();
  else if(state.view === "finish") renderFinish();
  else renderLesson(state.view);
}

loadState().then(renderAll);
})();